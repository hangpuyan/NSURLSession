//
//  ViewController.m
//  httpsDemo
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<NSURLSessionDataDelegate>

@property(nonatomic,strong) NSURLSession *session;

@end

@implementation ViewController
#pragma mark 懒加载
-(NSURLSession *)session{
    if(!_session){
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        _session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    }
    return _session;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self get12306];
}

//http的方式去访问12306
-(void)get12306{

    NSURL *url = [NSURL URLWithString:@"https://kyfw.12306.cn/otn/"];
    
    [[self.session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        //html 响应体
        NSString *htmlString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",htmlString);
        NSLog(@"error %@",error);
        
    }] resume];
}

#pragma mark delegate
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task
didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
 completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential * __nullable credential))completionHandler{

    /*
     1.challenge从服务器获得公钥的信息
     2.completionHandler 把验证结果告诉服务器
     */
    
    //判断验证方式
    if(challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust){
    //直接选择相信服务器,需要生成对称加密的秘钥,交给服务器
        NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
        //把秘钥交给服务器,填0表示相信服务器
        completionHandler(0,credential);
    }
}

@end
