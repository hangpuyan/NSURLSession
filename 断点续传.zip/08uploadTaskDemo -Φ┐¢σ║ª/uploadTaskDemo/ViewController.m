//
//  ViewController.m
//  uploadTaskDemo
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<NSURLSessionTaskDelegate>

@property(nonatomic,strong) NSURLSession *session;

@end

@implementation ViewController
#pragma mark 懒加载
-(NSURLSession *)session{
    if(!_session){
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        _session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    }
    return _session;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self uploadDemo2];
}

//带上传进度
-(void)uploadDemo2{

    
    //上传到webdev服务器,表明要向uploads文件夹下创建一个03.jpg
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/uploads/03.jpg"];
    //request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    //1.get -> put
    request.HTTPMethod = @"put";
    //2.Authorization: Basic YWRtaW46MTIzNDU=
    [request setValue:[self getAuthWithUsername:@"admin" password:@"12345"] forHTTPHeaderField:@"Authorization"];
    
    //文件的路径URL
     NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"03.jpg" withExtension:nil];
    
    [[self.session uploadTaskWithRequest:request fromFile:fileURL] resume];
    
}


//把图片上传到webdev服务器上
-(void)uploadDemo{
//1.session
    NSURLSession *session = [NSURLSession sharedSession];
    
    //上传到webdev服务器,表明要向uploads文件夹下创建一个03.jpg
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/uploads/03.jpg"];
    
    //request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    //1.get -> put
    request.HTTPMethod = @"put";
    //2.Authorization: Basic YWRtaW46MTIzNDU=
    [request setValue:[self getAuthWithUsername:@"admin" password:@"12345"] forHTTPHeaderField:@"Authorization"];
    
    //2 uploadTask
    /*
     1.请求
     2.本地文件的路径
     3.完成之后的回调
     */
    
    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"03.jpg" withExtension:nil];
    
    NSURLSessionUploadTask *uploadTask = [session uploadTaskWithRequest:request fromFile:fileURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        /*
         1.data 响应体
         2.response 响应头
         3.错误
         */
        
        NSLog(@"response:%@",response);
        NSLog(@"data:%@",data);
        NSLog(@"error:%@",error);
        
    }];
    
    //开启
    [uploadTask resume];
}

//Basic YWRtaW46MTIzNDU= (admin:12345)
//生成验证信息的字符串
-(NSString *)getAuthWithUsername:(NSString *)username password:(NSString *)password{
    NSString *string = [NSString stringWithFormat:@"%@:%@",username,password];
    NSString *base64String = [self base64Encode:string];
    return [NSString stringWithFormat:@"Basic %@",base64String];
}

//base64编码
-(NSString *)base64Encode:(NSString *)string{
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    return [data base64EncodedStringWithOptions:0];
}

#pragma mark sessionTaskDelegate
//每次发送一点数据就会调用该方法
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task
   didSendBodyData:(int64_t)bytesSent
    totalBytesSent:(int64_t)totalBytesSent
totalBytesExpectedToSend:(int64_t)totalBytesExpectedToSend{
/*
 1.本次发送的数据长度
 2.已经发送的数据长度
 3.文件总长度
 */
    //进度
    float progress = totalBytesSent * 1.0 / totalBytesExpectedToSend;
    NSLog(@"%f",progress);
}
@end
