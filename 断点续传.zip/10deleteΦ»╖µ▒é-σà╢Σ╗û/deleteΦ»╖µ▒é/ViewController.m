//
//  ViewController.m
//  delete请求
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<NSURLSessionTaskDelegate>

@property(nonatomic,strong) NSURLSession *session;
@property (weak, nonatomic) IBOutlet UIImageView *imageview;

@end

@implementation ViewController
#pragma mark 懒加载
-(NSURLSession *)session{
    if(!_session){
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        
        //统一设置请求头的信息 Authorization: Basic YWRtaW46MTIzNDU=
        config.HTTPAdditionalHeaders = @{@"Authorization":[self getAuthWithUsername:@"admin" password:@"12345"]};
        
        _session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:[NSOperationQueue mainQueue]];
        
    }
    return _session;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self displayImage];
}

//获取图片
-(void)displayImage{
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/uploads/03.JPG"];
    
    [[self.session downloadTaskWithURL:url completionHandler:^(NSURL * _Nullable location, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSLog(@"%@",[NSThread currentThread]);
        //location 图片下载的本地路径
        NSData *data = [NSData dataWithContentsOfURL:url];
        UIImage *image =[UIImage imageWithData:data];
        self.imageview.image = image;
        
    }] resume];
}

//删除webdev上面的图片资源
/*
 1.请求 get->delete
 2.请求头 加验证信息
 3.dataTask
 */
-(void)deleteDemo{
    //要删除文件的网络路径
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/uploads/03.jpg"];
    //request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    //1.get -> delete
    request.HTTPMethod = @"delete";
    //2.Authorization: Basic YWRtaW46MTIzNDU=
//    [request setValue:[self getAuthWithUsername:@"admin" password:@"12345"] forHTTPHeaderField:@"Authorization"];
    //3.dataTask
    [[self.session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSLog(@"error %@",error);
        NSLog(@"response %@",response);
        
    }] resume];
    
}

//Basic YWRtaW46MTIzNDU= (admin:12345)
//生成验证信息的字符串
-(NSString *)getAuthWithUsername:(NSString *)username password:(NSString *)password{
    NSString *string = [NSString stringWithFormat:@"%@:%@",username,password];
    NSString *base64String = [self base64Encode:string];
    return [NSString stringWithFormat:@"Basic %@",base64String];
}

//base64编码
-(NSString *)base64Encode:(NSString *)string{
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    return [data base64EncodedStringWithOptions:0];
}

@end
