//
//  ViewController.m
//  dataTaskDemo
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self postDemo];
}

-(void)postDemo{

    //1.创建session
    NSURLSession *session = [NSURLSession sharedSession];
    
    //2.请求
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/login.php"];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    //get->post
    request.HTTPMethod = @"post";
    //请求体
    //username=111&password=11
    NSString *bodyString = @"username=111&password=11";
    request.HTTPBody = [bodyString dataUsingEncoding:NSUTF8StringEncoding];
    
    [[session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",string);
        
        //不要忘记开启任务resume
    }] resume];
}

-(void)getJson2{

    //简便写法
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/demo.json"];
    [[[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",string);

        
    }] resume];
}

-(void)getJson{
    //默认是get请求方式
    
    //1.创建session
    NSURLSession *session = [NSURLSession sharedSession];
    
    //2.生成dataTask
    /*
     1.url
     2.完成时候的回调
     */
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/demo.json"];
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        /*
         1.响应体
         2.响应头
         3.错误
         */
        
        NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",string);
        
    }];
    
    //3.开启任务
    [dataTask resume];
}
@end
