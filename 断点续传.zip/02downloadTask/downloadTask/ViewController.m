//
//  ViewController.m
//  downloadTask
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self downloadTask];
}

//下载文件
-(void)downloadTask{

    //1.session
    NSURLSession *session = [NSURLSession sharedSession];
    //2.下载任务
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/mv.mp4"];
    
    [[session downloadTaskWithURL:url completionHandler:^(NSURL * _Nullable location, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        /*
         1.location 文件下载到本地的路径
         2.response 响应头
         3.错误
         */
        
        //文件确实下载了,但是文件会自动删除,再block返回之前要拷贝,打开文件,如果在block执行完成之后,文件就没删除了
        
        NSLog(@"%@",location.path);
        //拷贝文件cache
        NSFileManager *fileMan = [NSFileManager defaultManager];
        
        //文件保存路径
        NSString *fileSavePath = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:response.suggestedFilename];
        
        /*
         1.文件路径
         2.拷贝到哪里
         3.错误
         */
        [fileMan copyItemAtPath:location.path toPath:fileSavePath error:NULL];
        
        //3.开启任务
    }] resume];
    
    
}
@end
