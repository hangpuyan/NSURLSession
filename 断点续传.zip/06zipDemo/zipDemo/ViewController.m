//
//  ViewController.m
//  zipDemo
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "SSZipArchive.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self zipDemo];
}

//压缩文件
-(void)zipDemo{

    /*
     1.指定zip包生成的路径
     2.要打包的文件夹路径
     */
    [SSZipArchive createZipFileAtPath:@"/Users/apple/Desktop/bb.zip" withContentsOfDirectory:@"/Users/apple/Desktop/itcast"];
    
}

//获得压缩包
-(void)getZip{
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/demo.zip"];
    
    //downloadTask
    NSURLSessionDownloadTask *downloadTask = [session downloadTaskWithURL:url completionHandler:^(NSURL * _Nullable location, NSURLResponse * _Nullable response, NSError * _Nullable error) {
       
        //解压缩
        NSLog(@"%@",location.path);
        //放桌面
//        NSFileManager *fileMan = [NSFileManager defaultManager];
//        [fileMan copyItemAtPath:location.path toPath:@"/Users/apple/Desktop/aa.zip" error:NULL];
        
        /*
         1.压缩包的路径
         2.解压缩的路径
         */
        [SSZipArchive unzipFileAtPath:location.path toDestination:@"/Users/apple/Desktop/itcast"];
    }];
    
    [downloadTask resume];
}
@end
