//
//  ViewController.m
//  afn-sessionDemo
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self getXML];
}

-(void)getXML{
    //1. manager 又session来实现,使用方式不变
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //指定序列化器
    manager.responseSerializer = [AFXMLParserResponseSerializer serializer];
    
    [manager GET:@"http://127.0.0.1/videos.xml" parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        
        //默认afn是对json反序列化
        NSLog(@"%@",[responseObject class]);
        //xml解析
        NSXMLParser *parser = responseObject;
        parser.delegate = self;
        [parser parse];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
}

-(void)getBaidu{
//get
    //1. manager 又session来实现,使用方式不变
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //指定序列化器
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    [manager GET:@"http://www.baidu.com" parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        
        //默认afn是对json反序列化,html不能直接序列化
        NSString *string = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"%@",string);
       
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         NSLog(@"%@",error);
    }];
}

//文件下载
-(void)downloadDemo{
    //1. manager 又session来实现,使用方式不变
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    /*
     1.请求
     2.进度 NSProgress **
     3.指定下载文件的地址
     4.完成下载的回调
     */
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/mv.mp4"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    NSProgress *progress;
    
    [[manager downloadTaskWithRequest:request progress:&progress destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        
        //指定文件下载地址
        NSString *fileSavePath = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:response.suggestedFilename];
        //nsstring->url 本地路径不能使用URLWithString
        return [[NSURL alloc] initFileURLWithPath:fileSavePath];
   
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        
        NSLog(@"%@",filePath);
    }] resume];
    
    //kvo 观察者模式
    /*
     1.要观察他的对象
     2.观察哪个key
     3.选项 选择观察新的值或旧的值
     4.其他参数
     */
    [progress addObserver:self forKeyPath:@"fractionCompleted" options:NSKeyValueObservingOptionNew context:nil];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
//当被观察的对象发生改变,就会调用此方法
    /*
     1.观察哪个key
     2.观察的对象
     3.变化
     4.其他参数
     */
    if([object isKindOfClass:[NSProgress class]]){
        NSProgress *progress = object;
        double progress2 = progress.fractionCompleted;
        NSLog(@"%f",progress2);
    }
}

-(void)getDemo{
    //1. manager 又session来实现,使用方式不变
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    [manager GET:@"http://127.0.0.1/demo.json" parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        
        NSLog(@"%@",responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}

@end
