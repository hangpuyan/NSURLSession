//
//  ViewController.m
//  session下载进度
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

/*
 问题
 1.开始-暂停-暂停-继续-崩溃
 原因:点击多次暂停,resumeData为空,downloadTask创建报错
 
 2.继续-崩溃
 原因:resumeData为空,downloadTask创建报错
 
 3.开始-暂停-继续多次 进度混乱
 原因:开启了多个下载任务
 */
#import "ViewController.h"

@interface ViewController ()<NSURLSessionDownloadDelegate>

@property(nonatomic,strong) NSURLSession *session;

@property(nonatomic,strong) NSURLSessionDownloadTask *downloadTask;

//文件已经下载的信息
@property(nonatomic,strong) NSData *resumeData;

@end

@implementation ViewController

-(NSURLSession *)session{
    if(!_session){
        //session设置代理
        /*
         1.Configuration session的配置信息
         2.代理
         3.代理队列
         下载的过程中,一定是在子线程,但是我可以指定指定代理方法将在哪个队列上执行
         */
        
        //1.默认的session配置信息
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        /*
         defaultSessionConfiguration 默认保存缓存等数据
         ephemeralSessionConfiguration 不保存缓存等数据
         backgroundSessionConfigurationWithIdentifier 开启新的进程去做下载任务,当用户开启多屏幕的界面关闭app,改进程也随之关闭(看文档)
         */
        _session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    }
    return _session;
}


- (IBAction)beginClick:(id)sender {
    //开始
    [self downloadFile];
}

- (IBAction)pauseClick:(id)sender {
    //暂停
    //resumeData返回已经下载数据的信息?,不是文件的本身,是已经下载的文件信息,包含url,文件长度,etag.....
    [self.downloadTask cancelByProducingResumeData:^(NSData * _Nullable resumeData) {
        NSLog(@"----%@",resumeData);
        self.resumeData = resumeData;
        
        //保存resumeData
        NSString *fileSavePath = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"itcat.cz"];
        [resumeData writeToFile:fileSavePath atomically:YES];
        
    }];
    
    //对象为空,不能接受消息
    self.downloadTask = nil;
}

- (IBAction)resumeClick:(id)sender {
    //读取沙盒中的resumeData
     NSString *fileSavePath = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"itcat.cz"];
    
    self.resumeData = [NSData dataWithContentsOfFile:fileSavePath];
    
    //继续
    if(!self.resumeData){
        return;
    }
    
    //重新创建downloadTask,并且把resumeData已经下载的文件信息告诉他,内部会读取resumeData的信息,拼接请求头,range
    self.downloadTask = [self.session downloadTaskWithResumeData:self.resumeData];
    [self.downloadTask resume];
    
    self.resumeData = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

//下载文件-进度
-(void)downloadFile{
    
    //2.downloadTask
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/1.mp4"];
  
   self.downloadTask = [self.session downloadTaskWithURL:url];
    
      //3.resume
    [self.downloadTask resume];
}

#pragma mark delegate

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
      didWriteData:(int64_t)bytesWritten
 totalBytesWritten:(int64_t)totalBytesWritten
totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite{
/*
 得到一点数据,就调用该方法
 1.didWriteData 本次得到的数据长度
 2.totalBytesWritten 已经下载了多少数据的长度
 3.totalBytesExpectedToWrite 文件的总长度
 */
    
    //进度
    float progress = totalBytesWritten * 1.0 / totalBytesExpectedToWrite;
    NSLog(@"%f %@",progress,[NSThread currentThread]);
}

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
 didResumeAtOffset:(int64_t)fileOffset
expectedTotalBytes:(int64_t)expectedTotalBytes{
//断点续传的时候使用
}

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
didFinishDownloadingToURL:(NSURL *)location{
    //location 下载文件的本地路径
    NSLog(@"下载完成 %@",location.path);
    //及时的把文件拷贝到指定的地方,文件会被删除
}
@end
