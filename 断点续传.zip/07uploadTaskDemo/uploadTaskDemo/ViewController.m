//
//  ViewController.m
//  uploadTaskDemo
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self uploadDemo];
}

//把图片上传到webdev服务器上
-(void)uploadDemo{
//1.session
    NSURLSession *session = [NSURLSession sharedSession];
    
    //上传到webdev服务器,表明要向uploads文件夹下创建一个03.jpg
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/uploads/03.jpg"];
    
    //request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    //1.get -> put
    request.HTTPMethod = @"put";
    //2.Authorization: Basic YWRtaW46MTIzNDU=
    [request setValue:[self getAuthWithUsername:@"admin" password:@"12345"] forHTTPHeaderField:@"Authorization"];
    
    //2 uploadTask
    /*
     1.请求
     2.本地文件的路径
     3.完成之后的回调
     */
    
    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"03.jpg" withExtension:nil];
    
    NSURLSessionUploadTask *uploadTask = [session uploadTaskWithRequest:request fromFile:fileURL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        /*
         1.data 响应体
         2.response 响应头
         3.错误
         */
        
        NSLog(@"response:%@",response);
        NSLog(@"data:%@",data);
        NSLog(@"error:%@",error);
        
    }];
    
    //开启
    [uploadTask resume];
}

//Basic YWRtaW46MTIzNDU= (admin:12345)
//生成验证信息的字符串
-(NSString *)getAuthWithUsername:(NSString *)username password:(NSString *)password{
    NSString *string = [NSString stringWithFormat:@"%@:%@",username,password];
    NSString *base64String = [self base64Encode:string];
    return [NSString stringWithFormat:@"Basic %@",base64String];
}

//base64编码
-(NSString *)base64Encode:(NSString *)string{
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    return [data base64EncodedStringWithOptions:0];
}
@end
