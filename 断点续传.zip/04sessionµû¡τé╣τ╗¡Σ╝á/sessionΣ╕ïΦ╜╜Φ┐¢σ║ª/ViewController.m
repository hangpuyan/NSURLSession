//
//  ViewController.m
//  session下载进度
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//


#import "ViewController.h"

@interface ViewController ()<NSURLSessionDownloadDelegate>

@property(nonatomic,strong) NSURLSession *session;

@property(nonatomic,strong) NSURLSessionDownloadTask *downloadTask;

//文件已经下载的信息
@property(nonatomic,strong) NSData *resumeData;

@end

@implementation ViewController

-(NSURLSession *)session{
    if(!_session){
        //session设置代理
        /*
         1.Configuration session的配置信息
         2.代理
         3.代理队列 指定代理方法将在哪个队列上执行,指定线程
         */
        
        //1.默认的session配置信息
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        
        _session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    }
    return _session;
}


- (IBAction)beginClick:(id)sender {
    //开始
    [self downloadFile];
}

- (IBAction)pauseClick:(id)sender {
    //暂停
    //resumeData返回已经下载数据的信息?,不是文件的本身
    [self.downloadTask cancelByProducingResumeData:^(NSData * _Nullable resumeData) {
        NSLog(@"%@",resumeData);
        self.resumeData = resumeData;
    }];
}

- (IBAction)resumeClick:(id)sender {
    //继续
    //重新创建downloadTask,并且把resumeData已经下载的文件信息告诉他
    self.downloadTask = [self.session downloadTaskWithResumeData:self.resumeData];
    [self.downloadTask resume];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

//下载文件-进度
-(void)downloadFile{
    
    //2.downloadTask
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/mv.mp4"];
  
   self.downloadTask = [self.session downloadTaskWithURL:url];
    
      //3.resume
    [self.downloadTask resume];
}

#pragma mark delegate

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
      didWriteData:(int64_t)bytesWritten
 totalBytesWritten:(int64_t)totalBytesWritten
totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite{
/*
 得到一点数据,就调用该方法
 1.didWriteData 本次得到的数据长度
 2.totalBytesWritten 已经下载了多少数据的长度
 3.totalBytesExpectedToWrite 文件的总长度
 */
    
    //进度
    float progress = totalBytesWritten * 1.0 / totalBytesExpectedToWrite;
    NSLog(@"%f",progress);
}

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
 didResumeAtOffset:(int64_t)fileOffset
expectedTotalBytes:(int64_t)expectedTotalBytes{
//断点续传的时候使用
}

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
didFinishDownloadingToURL:(NSURL *)location{
    //location 下载文件的本地路径
    NSLog(@"下载完成 %@",location.path);
    //及时的把文件拷贝到指定的地方,文件会被删除
}
@end
