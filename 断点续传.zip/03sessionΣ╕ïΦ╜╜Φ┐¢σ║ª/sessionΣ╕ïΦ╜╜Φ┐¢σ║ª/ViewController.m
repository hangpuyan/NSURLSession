//
//  ViewController.m
//  session下载进度
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<NSURLSessionDownloadDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self downloadFile];
}

//下载文件-进度
-(void)downloadFile{

    //session设置代理
    /*
     1.Configuration session的配置信息
     2.代理
     3.代理队列 指定代理方法将在哪个队列上执行,指定线程
     */
    
    //1.默认的session配置信息
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //2.downloadTask
    NSURL *url = [NSURL URLWithString:@"http://127.0.0.1/mv.mp4"];
    //3.resume
   
    [[session downloadTaskWithURL:url] resume];
    
     //当下载task指定了block回调,就不会执行代理方法
//    [[session downloadTaskWithURL:url completionHandler:^(NSURL * _Nullable location, NSURLResponse * _Nullable response, NSError * _Nullable error) {
//        
//        NSLog(@"aa");
//        
//    }] resume];

}

#pragma mark delegate

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
      didWriteData:(int64_t)bytesWritten
 totalBytesWritten:(int64_t)totalBytesWritten
totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite{
/*
 得到一点数据,就调用该方法
 1.didWriteData 本次得到的数据长度
 2.totalBytesWritten 已经下载了多少数据的长度
 3.totalBytesExpectedToWrite 文件的总长度
 */
    
    //进度
    float progress = totalBytesWritten * 1.0 / totalBytesExpectedToWrite;
    NSLog(@"%f",progress);
}

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
 didResumeAtOffset:(int64_t)fileOffset
expectedTotalBytes:(int64_t)expectedTotalBytes{
//断点续传的时候使用
}

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask
didFinishDownloadingToURL:(NSURL *)location{
    //location 下载文件的本地路径
    NSLog(@"下载完成 %@",location.path);
    //及时的把文件拷贝到指定的地方,文件会被删除
}
@end
