//
//  ViewController.m
//  afndemo
//
//  Created by Apple on 16/2/21.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self uploadFile];
}

-(void)uploadFile{
AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    /*
     1.url
     2.参数
     3.构建 请求体 文件的数据等格式
     4.成功的回调
     5.失败的回调
     */
    [manager POST:@"http://127.0.0.1/upload/upload.php" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        //追加文件的内容到响应体
        /*
         1.文件的url
         2.服务器接收文件的标示
         3.错误
         */
        NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"03.jpg" withExtension:nil];
        
        [formData appendPartWithFileURL:fileURL name:@"userfile" error:NULL];
        
    } success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
        NSLog(@"%@",responseObject);
        
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        
    }];
}

-(void)postDemo{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    /*
     1.url
     2.参数
     3.成功的回调
     4.失败的回调
     */
    //提交参数 username=111&password=222
    NSDictionary *params = @{@"username":@"111",@"password":@"222"};
    
    [manager POST:@"http://127.0.0.1/login.php" parameters:params success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
        /*
         1.操作
         2.响应对象
         */
        //afn默认会把数据进行json反序列化
        NSLog(@"%@",responseObject);
        
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        
    }];
}

-(void)getDemo2{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    /*
     1.url
     2.参数
     3.成功的回调
     4.失败的回调
     */
    //提交参数 username=111&password=222
    NSDictionary *params = @{@"username":@"111",@"password":@"222"};
    
    [manager GET:@"http://127.0.0.1/login.php" parameters:params success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
        /*
         1.操作
         2.响应对象
         */
        //afn默认会把数据进行json反序列化
        NSLog(@"%@",responseObject);
        
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        
    }];
}

-(void)getDemo{
    //找打对应管理类,当前manager是connection去实现
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    /*
     1.url
     2.参数
     3.成功的回调
     4.失败的回调
     */
    [manager GET:@"http://127.0.0.1/demo.json" parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
        /*
         1.操作
         2.响应对象
         */
        //afn默认会把数据进行json反序列化
        NSLog(@"%@",responseObject);
        
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        
    }];
}

@end
